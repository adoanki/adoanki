from chatterbot.logic import LogicAdapter
import json
import time
import os


class QAAdapter(LogicAdapter):
    """
    Return a specific response to a specific input.

    :kwargs:
        * *input_text* (``str``) --
          The input text that triggers this logic adapter.
        * *output_text* (``str``) --
          The output text returned by this logic adapter.
    """

    def __init__(self, chatbot, **kwargs):

        super().__init__(chatbot, **kwargs)
        from chatterbot.conversation import Statement

        # Intialize the and load the  Journey and qUESTION json file

        with open("./data/QJourney.json", "r") as read_file:
            self.QJourney = json.load(read_file)
        with open("./data/QTable.json", "r") as read_file:
            self.QTable = json.load(read_file)
        self.QDB = self.create_QDB(self.QTable)
        self.JQDB = self.create_JourneyDB(self.QJourney)
        # print("print QDB", self.QDB)
        # print("print JQDB", self.JQDB)

        self.input_text = kwargs.get('input_text')
        # output_text = "bolo"
        self.response_statement = Statement(text="")

    def can_process(self, statement):
        # if statement == self.input_text:
        return True

    def create_QDB(self, QTable):
        QDB = {}

        for elm0 in QTable:
            for key0, value0 in elm0.items():
                k = str(elm0['Sno'])
                v = str(elm0['Question'])
                v1 = str(elm0['Options'])
                v2 = str(elm0['ValidAnswer'])
                QDB[k] = [v, v1, v2]
                # print("QDB",QDB[k])
        return QDB

    def create_JourneyDB(self, QJourney):
        JQDB = {}
        for elm0 in QJourney:

            for key0, value0 in elm0.items():
                k = str(elm0['QAKey'])
                print("print key", k)
                v = str(elm0['NextQ'])

                print("print value", v)
                
				
                JQDB[k] = v
        return JQDB

    def validate(self, curr_question, curr_resp):
        Qobj = self.QDB[curr_question]
        # print("QOBJ", Qobj)
        # todo Very bad coding
        response = str(curr_resp).upper()
        answer_list = list(Qobj[2].split(","))
        if answer_list:
            if any(response in s for s in answer_list):
                # validans=str(Qobj[2]).find(str(curr_resp).upper())
                # print("Found Valid answer at", validans)
                return "f"
        else:
            return "n"

    def process(self, statement, additional_response_selection_parameters=None):
        from chatterbot.logic import specific_response
        from chatterbot.conversation import Statement

        sep = "!!!"

        user_input = str(statement.text).upper()
        curr_question = user_input[0:user_input.find(sep)]
        curr_resp = user_input[user_input.find(sep) + len(sep):]
        print("User Input", user_input)
        resp_string = ''
        validation = self.validate(curr_question, curr_resp)
        print("validation", validation)
        # if user responds with below words than bot will end the chat
        exit_words = ["stop", "exit", "quit"]
        if curr_resp.lower() in exit_words:
            resp_string = "  Thanks for coming here.Have a nice day"
        else:
            # code to do answer validation only if expected answer list is non empty
            if validation:
                if validation in "f":
                    nextq_id = self.JQDB[user_input]
					
                    nextq = self.QDB[nextq_id]
                    resp_string = nextq_id + sep + nextq[0] + nextq[1]
                    print("fresp_string", nextq_id)
					
                elif validation in "n":
                    nextq = self.JQDB[curr_question]
                    resp_string = curr_question + sep + nextq[0] + nextq[1]
                    print("nresp_string", resp_string)
            else:
                #user_input = user_input.split("!!!")[0]
                nextq_id = self.JQDB[curr_question]

                nextq = self.QDB[nextq_id]

                resp_string = nextq_id + sep + nextq[0] + nextq[1]
                # print("resp_string", resp_string)


        self.response_statement.confidence = 1
        self.response_statement = Statement(text=resp_string)
        return self.response_statement
