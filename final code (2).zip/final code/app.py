from chatbot import chatbot

import json
from os import path, walk
from flask import Flask, render_template, request, jsonify,redirect,url_for,Blueprint
print("Hello")
app = Flask(__name__)
app.jinja_env.auto_reload = True
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.static_folder = 'static'


@app.route("/")
def home():


    #return render_template("index.html",jsonfile=json.dumps(data))
    return render_template("index.html")


@app.route("/get")
def get_bot_response():
    userText = request.args.get('msg')
    return str(chatbot.get_response(userText))


@app.route("/json_ques")
def api_all():
    import json

    #Not getting used in the code
    with open ('C://Temp//coronabot-chatterbot-master//book1.json')  as json_full:
        json_data=json.load(json_full)

        return str(json_data)
        # return json.dumps({Success:True})

if __name__ == "__main__":
    
    dir = ['./data/']
    extra_files = dir[:]

    for directory in dir:
        for dirname, dirs, files in walk(directory):
	        
	        for filename in files: 
	            filename = path.join(dirname, filename)
	            if path.isfile(filename):
		            extra_files.append(filename)
    app.run(extra_files=extra_files,host='0.0.0.0',debug=True)