from chatterbot import ChatBot
from chatterbot.conversation import Statement

class Test:
	chatbot = ChatBot(
		'Robo Solution Designer',
		storage_adapter='chatterbot.storage.SQLStorageAdapter',
		logic_adapters=[
			'chatterbot.logic.MathematicalEvaluation',
			'chatterbot.logic.TimeLogicAdapter',
			'chatterbot.logic.BestMatch',
			{
				'import_path': 'chatterbot.logic.BestMatch',
				'default_response': 'I am sorry, but I do not understand. I am still learning.',
				'maximum_similarity_threshold': 0.90
			}
		],
		database_uri='sqlite:///database.sqlite3'
	)

	def test_search_text_results_after_training(self):
			"""
			ChatterBot should return close matches to an input
			string when filtering using the search_text parameter.
			"""
			self.chatbot.storage.create_many([
				Statement('Example A for search.'),
				Statement('Another example.'),
				Statement('Example B for search.'),
				Statement(text='Another statement.'),
			])

			results = list(self.chatbot.storage.filter(
				search_text=self.chatbot.storage.tagger.get_bigram_pair_string(
					'Example B for search.'
				)
			))
			print('ashdjashdkjashdkjsa',results)
			self.assertEqual(len(results), 1)
			self.assertEqual('Example A for search.', results[0].text)
		
t = Test()
t.test_search_text_results_after_training()