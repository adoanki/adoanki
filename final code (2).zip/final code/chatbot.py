from chatterbot import ChatBot

chatbot = ChatBot(
    'Robo Solution Designer',
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    logic_adapters=[

        'qa_adapter.QAAdapter',

        {
            'import_path': 'qa_adapter.QAAdapter',
            'input_text': 'I am sorry, but I do not understand. I am still learn'

        }
    ],
    database_uri='sqlite:///database.sqlite3'
)

# Training With Own Questions 
# from chatterbot.trainers import ListTrainer

# trainer = ListTrainer(chatbot)

# training_data_quesans = open('training_data/ques_ans.txt').read().splitlines()
# training_data_personal = open('training_data/personal_ques.txt').read().splitlines()

# training_data = training_data_quesans + training_data_personal


# trainer.train(training_data)

# Training With Corpus
# from chatterbot.trainers import ChatterBotCorpusTrainer

# trainer_corpus = ChatterBotCorpusTrainer(chatbot)

# trainer_corpus.train(
#    'chatterbot.corpus.english'
# )
